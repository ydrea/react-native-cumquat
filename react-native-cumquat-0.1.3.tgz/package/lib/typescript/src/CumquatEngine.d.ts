import type { EngineConfig, FrameSnapshot, PickResult, POIInput, SensorState, ViewState } from './types.js';
export declare class CumquatEngine {
    #private;
    private constructor();
    static getNativeVersion(): string;
    static create(config?: EngineConfig): CumquatEngine;
    initialize(pois: readonly POIInput[]): void;
    setViewState(viewState: ViewState): void;
    update(sensorState: SensorState): number;
    getFrame(): FrameSnapshot;
    pick(x: number, y: number, radiusPixels?: number): PickResult;
    dispose(): void;
}
//# sourceMappingURL=CumquatEngine.d.ts.map